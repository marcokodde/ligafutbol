<x-slot name="header">
    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
        {{__($manage_title)}}
    </h2>
</x-slot>
