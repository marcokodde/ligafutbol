@if($show_header_card)
    <header class="card-header">
        <p class="card-header-title">
        <span class="icon"><i class="mdi mdi-account-multiple"></i></span>
        {{ $header_card}}
        </p>
        <a href="#" class="card-header-icon">
        <span class="icon"><i class="mdi mdi-reload"></i></span>
        </a>
    </header>
@endif
