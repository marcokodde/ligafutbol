
<input type="text"
    wire:model="search"
    placeholder="{{__($search_label)}}"
    class="mb-4 w-1/3 shadow appearance-none border rounded  py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
>
