        <!-- Tailwind is included -->
        <link rel="stylesheet" href="{{asset('admin-one/dist/css/main.css')}}">
        <link rel="apple-touch-icon" sizes="180x180" href="{{asset('admin-one/dist/apple-touch-icon.png')}}"/>
        <link rel="icon" type="image/png" sizes="32x32" href="{{asset('admin-one/dist/favicon-32x32.png')}}"/>
        <link rel="icon" type="image/png" sizes="32x32" href="{{asset('admin-one/dist/favicon-16x16.png')}}"/>
        <link rel="mask-icon" href="{{asset('admin-one/dist/safari-pinned-tab.svg')}}" color="#00b4b6"/>

        <!-- Tailwind CSS -->
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
