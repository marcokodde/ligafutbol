
    <thead>
        <tr class="bg-gray-100">
            <th class="px-4 py-1">{{__("Role")}}</th>
            <th class="px-4 py-1">{{__("Name")}}</th>
            <th class="px-4 py-1 text-left">{{__("Full Access?")}}</th>
            <th colspan="2" class="px-4 py-1 text-center">{{__("Actions")}}</th>
        </tr>
    </thead>
